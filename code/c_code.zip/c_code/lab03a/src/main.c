/*
 * main.c
 *
 *  Created on: Mar 15, 2015
 *      Author: C16John.Terragnoli
 */


//--------------------------------------------------------------------
//-- Name:	Chris Coulston
//-- Date:	Feb 25, 2015
//-- File:	lec18.c
//-- Event:	Lecture 18
//-- Crs:	ECE 383
//--
//-- Purp:	Examines how to interface custom IP to microBlaze.
//--
//-- Documentation:	I borrowed some techniques from my ECE382 examples
//--
//-- Academic Integrity Statement: I certify that, while others may have
//-- assisted me in brain storming, debugging and validating this program,
//-- the program itself is my own work. I understand that submitting code
//-- which is the work of other individuals is a violation of the honor
//-- code.  I also understand that if I knowingly give my original work to
//-- another individual is also a violation of the honor code.
//-------------------------------------------------------------------------
#include <xuartlite_l.h>					// Contains XUartLite_RecvByte
#include <xparameters.h>
#include <xil_io.h>							// Contains Xil_Out8 and its variations
#include <stdio.h>							// Contains xil_printf

#define	uartReadReg				0x84000000			// read <= RX, write=>TX
#define Lbus_out				0x83000000		//	"0000000000000000" & Lbus_out; 0
#define	Rbus_out				0x83000004		//	"0000000000000000" & Rbus_out; 1
#define flagQ					0x83000008		//  "000000000000000000000000" & flagQ ; 2
#define	triggerVolt				0x8300000C		// 	triggerVolt => unsigned(slv_reg3(9 downto 0)) 3
#define triggerTime				0x83000010		//	triggerTime => unsigned(slv_reg4(9 downto 0)), 4
#define	exLbus					0x83000014 		//  exLbus=>slv_reg5(15 downto 0), 5
#define exRbus					0x83000018		//	exRbus => slv_reg6(15 downto 0), 6
#define	exSel					0x8300001C		//	exSel => slv_reg7(0), 7
#define exWen					0x83000020		// 	exWen => slv_reg8(0), 8
#define	exWrAddr				0x83000024		// 	exWr => slv_reg9(9 downto 0), 9
#define flagClear				0x83000028		//  flagClear => slv_reg10(7 downto 0)); 10


#define count_HOLD				0x00				// The control bits are defined in the VHDL
#define	count_COUNT				0x01				// code contained in lec18.vhdl.  They are
#define	count_LOAD				0x02				// added here to centralize the bit values in
#define count_RESET				0x03				// a single place.

#define zero_c 					0
#define one_c					1

//trigger variables
#define	centerVolt				510
#define	centerTime				320
#define	increment				4
#define	upperVolt				centerVolt+200
#define	lowerVolt				centerVolt-200
#define	upperTime				centerTime+300
#define	lowerTime				centerTime-300

int R_data[600],L_data[600];
int beginningIndex, index, triggerTimeIndex;




int main(void) {


	setup();






    while(1) {
		buttonControl();

		//write using c code bram
		if(Xil_In32(exSel)==1){
			manipData();
		}

    } // end while 1
    return 0;



} // end main




/**
 * see if you can get anything at all to write to the screen.
 */
void manipData(){
	int i;


	//collecting datapoints.
	for(i = 0; i<600; i++){
		R_data[i] = Xil_In32(Rbus_out) + 200 + 0b1000000000000000;
		L_data[i] = Xil_In32(Lbus_out) + 200 + 0b1000000000000000;
	}


	//finding where the beginning of the data should be found.
	for(i = 0; i<601; i++){
		if((Xil_In32(triggerVolt) > (L_data[i] >> 6))&&
				Xil_In32(triggerVolt) < (L_data[i-1] >> 6)){

			beginningIndex = i;
					break;
		}
	}

	index = beginningIndex;
	index += 16;

	triggerTimeIndex = Xil_In16(triggerTime);

	//writing the information to BRAM.
	for(i = 0; i<601; i++){
		Xil_Out32(exWrAddr, triggerTimeIndex);

		//get the needed data to the BRAM1!
		Xil_Out32(exLbus, L_data[triggerTimeIndex+2]);
		Xil_Out32(exRbus, R_data[triggerTimeIndex]);

		Xil_Out32(exSel, triggerTimeIndex);
		Xil_Out32(exWen, triggerTimeIndex);

		index++;
		triggerTimeIndex++;

		if(index==601){
			index = 0;
		}
	}
}



void buttonControl(){
	u16  c;
	c = XUartLite_RecvByte(uartReadReg);
	xil_printf("character: %c\r\n",c);


	switch(c) {

			    		//-------------------------------------------------
			    		// Reply with the help menu
			    		//-------------------------------------------------
		    		case 'w':
		    			if(Xil_In32(triggerVolt)>lowerVolt){
		    				Xil_Out32(triggerVolt,Xil_In32(triggerVolt)-increment);
		    			}

		    			break;


		    		case 's':
		    			if(Xil_In32(triggerVolt)<upperVolt){
		    				Xil_Out32(triggerVolt,Xil_In32(triggerVolt)+increment);
		    			}
		    			break;

		    		case 'a':
		    			if(Xil_In32(triggerTime)>lowerTime){
		    				Xil_Out32(triggerTime,Xil_In32(triggerTime)-increment);
		    			}
		    			break;

		    		case 'd':
		    			if(Xil_In32(triggerTime)<upperTime){
		    				Xil_Out32(triggerTime,Xil_In32(triggerTime)+increment);
		    			}
		    			break;

		    		case 'r':

		    			Xil_Out32(triggerTime,centerTime);
		    			Xil_Out32(triggerVolt,centerVolt);

		    			break;


		    		case 'x':

		    			if(Xil_In32(exSel)==0x00000001){
		    				Xil_Out32(exSel,0x00000000);
		    				xil_printf("	exSel  = %x\r\n",Xil_In32(exSel));


		    			}else if(Xil_In32(exSel) == 0x00000000){
		    				Xil_Out32(exSel,0x00000001);
		    				xil_printf("	exSel  = %x\r\n",Xil_In32(exSel));
		    			}
		    		break;


//		    		case 'g':
//		    				xil_printf("	Lbus_out  = %x\r\n",Xil_In32(Lbus_out));
//		    				xil_printf("	Rbus_out  = %x\r\n",Xil_In32(Rbus_out));
//		    //				xil_printf("	triggerVolt  = %x\r\n",Xil_In32(triggerVolt));
//		    //				xil_printf("	triggerTime  = %x\r\n",Xil_In32(triggerTime));
//		    		break;


			          //-------------------------------------------------
			          // Unknown character was
			          //-------------------------------------------------
			    	default:
			    			xil_printf("unrecognized character: %c\r\n",c);
			    	break;
			    	} // end switch
}


void setup(){
	Xil_Out32(exSel,0);

	//centering the triggers.
	Xil_Out16(triggerTime,centerTime);
	Xil_Out16(triggerVolt,centerVolt);
}

/*
 * nothing in here yet
 */
void storeData(){
	int i;

	for(i = 0; i <600; i++){
//		while(Xil_In32(flagQ) && 0x00000001) == 0);
		Xil_Out16(flagClear,0x00000001);
		Xil_Out16(flagClear,0x00000000);
	}
}


